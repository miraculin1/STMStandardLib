var modules =
[
    [ "SVD File Schema Levels", "group__svd___format__gr.html", "group__svd___format__gr" ],
    [ "Element Groups", "group__elem__type__gr.html", "group__elem__type__gr" ],
    [ "SVD Extension in Version 1.1", "group__svd___format__1__1__gr.html", "group__svd___format__1__1__gr" ],
    [ "CMSIS-SVD Schema File Ver. 1.0", "group__schema__gr.html", null ],
    [ "CMSIS-SVD Schema File Ver. 1.1 (draft)", "group__schema__1__1__gr.html", null ]
];